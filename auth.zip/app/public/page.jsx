import React from 'react'

const Public = () => {
  return (
    <div>
      PublicPublicPublicPublic
    </div>
  )
}

export default Public
