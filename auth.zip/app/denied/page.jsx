import React from 'react'

const Denied = () => {
  return (
    <div>
      Access Denied!
    </div>
  )
}

export default Denied
