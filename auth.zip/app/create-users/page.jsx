import React from 'react'
import UserForm from '../(componentes)/UserForm'

const CreateUsers = () => {
  return (
    <div>
     <UserForm/>
    </div>
  )
}

export default CreateUsers
